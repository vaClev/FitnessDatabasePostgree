package DataBase;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ShowDB extends DataBase{

    //  Вывод на экран результата SQL-запроса
    private void print(ResultSet result) throws SQLException {
        int columns = result.getMetaData().getColumnCount();
        while (result.next()) {
            for (int i = 1; i <= columns; i++) {
                System.out.print(result.getString(i) + "\t");
            }
            System.out.println();
        }
    }
    //  Вывод на экране список программ
    public void showProgramsElements() throws SQLException {
        statement = getConnect();
        String res = String.format("select programmname, duration, maxmembers from publicProgramms");
        result = statement.executeQuery(res);
        print(result);
        closeConnection(statement);
    }

    // Вывод времени абонемента клиента
    public void showTicketTime(String id) throws SQLException {
        statement = getConnect();
        String res = String.format("select ticketdate from members where id = '%s'", id);
        result = statement.executeQuery(res);
        print(result);
        closeConnection(statement);
    }
    // Вывод на экран списка сотрудников определённой должности
    public void showEmployeeByStatus(int status, boolean showId)  {
        try {
            statement = getConnect();
            String res;
            if(!showId){
                res = String.format("select name, secondName, age from employees where status = '%d';", status);
            } else {
                res = String.format("select name, secondName, id from employees where status = '%d';", status);
            }
            result = statement.executeQuery(res);
            print(result);
            closeConnection(statement);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Вывод на экран списка сотрудников определённой должности
    public void showPrograms()  {
        try {
            statement = getConnect();
            String res = "select id, programmName from publicProgramms";
            result = statement.executeQuery(res);
            print(result);
            closeConnection(statement);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Вывод на экран списка клиентов
    public void showMembers()  {
        try {
            statement = getConnect();
            String res = "select name, secondName, age from members";
            result = statement.executeQuery(res);
            print(result);
            closeConnection(statement);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    // Вывод одного поля клиента по запросу (кошелёк)
    public void showMemberByQuery(String password, String query) throws SQLException {
        statement = getConnect();
        String res = String.format("select %s from members where id = '%s';", query, password);
        result = statement.executeQuery(res);
        String res1 = result.toString();
        print(result);
        closeConnection(statement);
    }
}
