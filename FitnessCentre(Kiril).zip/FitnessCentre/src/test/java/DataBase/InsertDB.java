package DataBase;

import VisitorPackage.*;

import java.sql.SQLException;

public class InsertDB extends DataBase {

    // Создание нового клиента
    public void newMember() throws SQLException {
        Member temp = new Member("", "", 0);
        if (temp.age >= 18) {
            insertVisitor(temp, -1);
        }
    }

    // Создание нового Работника
    public void newEmployee(int status) throws SQLException {
        Visitor temp;
        do {
            temp = createNewEmployee(status);
        }
        while (!checkEmployeeById(temp));
        insertVisitor(temp, status);
    }

    // Проверка на одинаковый пароль
    private boolean checkEmployeeById(Visitor temp) throws SQLException {
        if (new ReturnDB().findVisitorByPassword(temp.id) == null) {
            return true;
        } else {
            return false;
        }
    }

    // Создание конкретного Работника
    Visitor createNewEmployee(int status) {
        if (status == 0) {
            return new Trainer();
        } else if (status == 1) {
            return new Admin();
        } else if (status == 2) {
            return new Director();
        } else {
            return null;
        }
    }


    // Создание SQL-запроса на добавление
    private String makeInsertQuery(Visitor v1, int status) {
        if (status >= 0) {
            return String.format(
                    "insert into employees values('%s', '%s', '%s', '%d', '%d')",
                    v1.id, v1.name, v1.secondName, v1.age, status);
        } else if (status == -1) {
            Member m1 = (Member) v1;
            int g = m1.gender == 'm' ? 1 : 0;
            return String.format(
                    "insert into members values('%s', '%s', '%s', '%d', %d, 0)",
                    m1.id, m1.name, m1.secondName, m1.age, g);
        }
        return null;
    }

    // Добавление человека в БД
    private void insertVisitor(Visitor v1, int status) throws SQLException {
        statement = getConnect();
        statement.executeUpdate(makeInsertQuery(v1, status));
        closeConnection(statement);
    }
}
