package DataBase;

import MainPackage.*;
import java.sql.*;

public class DataBase {
    protected Connection connection;
    protected Statement statement;
    protected ResultSet result;

// Подключение к БД
    protected Statement getConnect() throws SQLException {
        String jdbcUrl = "jdbc:postgresql://localhost:5433/FitnessCentre";
        String username = "postgres";
        String password = "1234";
        connection = DriverManager.getConnection(
                jdbcUrl,
                username,
                password);

        return connection.createStatement();
    }

// Закрытие подключения
public void closeConnection(Statement statement) throws SQLException {
        connection.close();
        statement.close();
    }

}
