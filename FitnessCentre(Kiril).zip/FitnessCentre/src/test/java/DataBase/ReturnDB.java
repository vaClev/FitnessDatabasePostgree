package DataBase;

import VisitorPackage.*;

import java.sql.SQLException;

public class ReturnDB extends DataBase {


    //  Вывод клиента по паролю
    public Member findMemberByPassword(String password) throws SQLException {
        statement = getConnect();
        Member temp = null;
        String res = String.format("select * from members where id = '%s';", password);
        result = statement.executeQuery(res);
        while (result.next()) {
            temp = getMember();
        }
        closeConnection(statement);
        return temp;
    }
    //  Вывод работника по паролю
    public Visitor findVisitorByPassword(String password) throws SQLException {
        statement = getConnect();
        Visitor temp = null;
        String res = String.format("select * from employees where id = '%s';", password);
        result = statement.executeQuery(res);
        while (result.next()) {
            temp = createEmployee(
                    result.getString("id"),
                    result.getString("name"),
                    result.getString("secondname"),
                    result.getInt("age"),
                    result.getInt("status"));
        }
        closeConnection(statement);
        return temp;
    }

    //  Создание объекта "Клиент" по SQL-запросу
    private Member getMember() throws SQLException {
        Member temp = new Member(
                result.getString("name"),
                result.getString("secondName"),
                result.getInt("age"),
                result.getString("gender").toCharArray()[0],
                result.getInt("wallet"),
                result.getString("id"),
                result.getDate("ticketDate"));
        return temp;
    }

    // Создание конкретного Работника
    private Visitor createEmployee(String id, String name, String secondName, int age, int status) {
        if (status == 0) {
            return new Trainer(id, name, secondName, age);
        } else if (status == 1) {
            return new Admin(id, name, secondName, age);
        } else if (status == 2) {
            return new Director(id, name, secondName, age);
        } else {
            return null;
        }
    }
}