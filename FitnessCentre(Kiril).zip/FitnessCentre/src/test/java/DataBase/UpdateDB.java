package DataBase;

import VisitorPackage.Member;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class UpdateDB extends DataBase {

    ReturnDB returnDB = new ReturnDB();

    //  Обновление даты абонемента клиента
    public void updateDate(String id, int summ) throws SQLException {
        Member temp = returnDB.findMemberByPassword(id);
        statement = getConnect();
        Calendar calendar = temp.calendar;
        if (calendar == null) {
            calendar = new GregorianCalendar();
        }
        if(summ == 2_500){
            calendar.add(Calendar.MONTH,1);
        } else if(summ == 25_000){
            calendar.add(Calendar.YEAR,1);
        }
        String time = calendar.getTime().toString();
        statement.executeUpdate(makeUpdateCalendarQuery(id, time));
        closeConnection(statement);
    }
    //  Обновление кошелька клиента
    public void updateWallet(String id, int summ) throws SQLException {
        Member temp = returnDB.findMemberByPassword(id);
        statement = getConnect();
        if ((summ < 0) && !(-summ <= temp.wallet)) {
            System.out.println("Error: not enough money");
            return;
        } else {
            temp.wallet += summ;
        }
        statement.executeUpdate(makeUpdateWalletQuery(id, summ));
        closeConnection(statement);
    }

    // Создание SQL-запроса на обновление кошелька клиента
    private String makeUpdateWalletQuery(String id, int summ) {
        return String.format(
                "update members set wallet = wallet + %d where id = '%s'",
                summ, id
        );
    }
    // Создание SQL-запроса на обновление даты абонемента клиента
    private String makeUpdateCalendarQuery(String id, String time) {
        return String.format(
                "update members set ticketdate = '%s' where id = '%s'",
                time, id
        );
    }

}
