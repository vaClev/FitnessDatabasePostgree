package DataBase;

import java.sql.SQLException;

public class DeleteDB extends DataBase{

    // Удаление человека из БД
    public void deletePeople(String id, String flag) throws SQLException {
        statement = getConnect();
        statement.executeUpdate(makeDeleteMemberQuery(id, flag));
        closeConnection(statement);
    }

    // Создание SQL-запроса на удаление человека
    private String makeDeleteMemberQuery(String id, String flag) {
        if (flag == "employee") {
            return String.format(
                    "delete from employees where id = '%s'",
                    id);
        } else if (flag == "member") {
            return String.format(
                    "delete from members where id = '%s'",
                    id);
        }
        return null;
    }

}
