package VisitorPackage;

import DataBase.*;
import MainPackage.Main;


import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.UUID;

public abstract class Visitor extends DataBase implements VisitorInterface {
    public String name;
    public String secondName;
    public int age;
    public String id;
    int choice = -1;
    static InsertDB insertDB = new InsertDB();
    static DeleteDB deleteDB = new DeleteDB();
    static UpdateDB updateDB = new UpdateDB();
    static ReturnDB returnDB = new ReturnDB();
    static ShowDB showDB = new ShowDB();

    public Visitor() {}

    public Visitor(String id, String name, String secondName, int age) {
        this.id = id;
        this.name = name;
        this.secondName = secondName;
        this.age = age;
    }

    public Visitor(String name, String secondName, int age) {
        this.name = name;
        this.secondName = secondName;
        this.age = age;
        id = UUID.randomUUID().toString().substring(0, 5);
    }

    public void addTrainer() throws SQLException {
        insertDB.newEmployee( 0);
    }

    public void delTrainer() throws SQLException {
        System.out.print("Enter trainer's id for remove: ");
        String enter = Main.scanner.nextLine();
        enter = Main.scanner.nextLine();
        deleteDB.deletePeople(enter, "employee");
    }

    boolean checkChoice() {
        try {
            System.out.print("Enter your answer - ");
            choice = Main.scanner.nextInt();
            System.out.println();
            return true;
        } catch ( InputMismatchException ex) {
            System.out.println("Error");
            Main.scanner.nextLine();
            choice = -1;
            System.out.println();
            return false;
        }
    }
}
