package VisitorPackage;

import DataBase.*;
import MainPackage.*;


import java.sql.SQLException;
import java.util.*;

public class Member extends Visitor implements VisitorInterface {
    static Calendar calendar1 = new GregorianCalendar();
    public char gender;
    public int wallet = 5;
    List<String> visitedList = new LinkedList<>();
    public Calendar calendar;

    DataBase dataBase;


    public Member(String name, String secondName, int age, char gender, int wallet) {
        super(name, secondName, age);
        this.gender = gender;
        this.wallet = wallet;
        id = UUID.randomUUID().toString().substring(0, 5);
    }
    public Member(String name, String secondName, int age, char gender, int wallet, String id) {
        super(name, secondName, age);
        this.gender = gender;
        this.wallet = wallet;
        this.id = id;
    }
    public Member(String name, String secondName, int age, char gender, int wallet, String id, Date ticketDate) {
        super(name, secondName, age);
        this.gender = gender;
        this.wallet = wallet;
        calendar = Calendar.getInstance();
        calendar.setTime(ticketDate);
        this.id = id;
    }

    public Member(String name, String secondName, int age) {
        super(name, secondName, age);
        anketa();
    }

    public void anketa() {
        System.out.println("Hello our new member!");
        System.out.print("What is your name? - ");
        name = Main.scanner.nextLine();
        name = Main.scanner.nextLine();
        System.out.print("What is your secondName? - ");
        secondName = Main.scanner.nextLine();
        System.out.println("Nice to meet you " + name + "! How old are you?");
        age = Main.scanner.nextInt();
        if (age < 18) {
            System.out.println("You so young little kitty");
            return;
        }
        System.out.println("What's your gender?");
        String temp = Main.scanner.nextLine().toLowerCase();
        temp = Main.scanner.nextLine().toLowerCase();
        gender = temp.charAt(0);
        System.out.println();
        System.out.print("Enter your password: ");
        id = Main.scanner.nextLine();

    }

    public void visitorShowMenu() throws SQLException {
        do {
            System.out.println();
            System.out.println("1) Open current trainers");
            System.out.println("2) Open current programs");
            System.out.println("3) Open your wallet-balance");
            System.out.println("4) Open your programs");
            System.out.println("5) Open your ticket");
            System.out.println("0) Return to member menu");
            visitorShowLogistic();
        } while (choice != 0);
    }

    public void visitorAddMenu() throws SQLException {
        do {
            System.out.println();
            System.out.println("1) Added your wallet");
            System.out.println("2) Sign-in program");
            System.out.println("3) Buy new ticket-season");
            System.out.println("0) Return to member menu");
            visitorAddLogistic();
        } while (choice != 0);
    }

    public void visitorDelMenu() {
        do {
            System.out.println();
            System.out.println("1) Sign-out program");
            System.out.println("0) Return to member menu");
            visitorDelLogistic();
        } while (choice != 0);
    }

    public void visitorShowLogistic() throws SQLException {
        if (checkChoice()) {
            switch (choice) {
                case 1:
                    showTrainerDBList();
                    break;
                case 2:
                    showProgramsDBList();
                    break;
                case 3:
                    showWalletById();
                    break;
                case 4:
                    showMyPrograms();
                    break;
                case 5:
                    showMyTime();
                    break;
                case 0:
                    return;
                default:
                    System.out.println();
                    System.out.println("Wrong enter");
            }
        }
        System.out.println();
    }

    private void showProgramsDBList() throws SQLException {
        showDB.showProgramsElements();
    }

    private void showTrainerDBList() throws SQLException {
        showDB.showEmployeeByStatus(0, false);
    }

    private void showWalletById() throws SQLException {
        showDB.showMemberByQuery(id, "wallet");


    }

    public void visitorAddLogistic() throws SQLException {
        if (checkChoice()) {
            switch (choice) {
                case 1:
                    pay();
                    break;
                case 2:
                    joinProgram();
                    break;
                case 3:
                    buyTicket();
                    break;
                case 0:
                    return;
                default:
                    System.out.println();
                    System.out.println("Wrong enter");
            }
        }
        System.out.println();
    }

    public void visitorDelLogistic() {
        if (checkChoice()) {
            switch (choice) {
                case 1:
                    deleteProgram();
                    break;
                case 0:
                    return;
                default:
                    System.out.println();
                    System.out.println("Wrong enter");
            }
        }
        System.out.println();
    }

    public void showMyTime() throws SQLException {
        showDB.showTicketTime(id);
    }

    public void showMyPrograms() {
        if (calendar != null && calendar.getTime().after(calendar1.getTime())) {
            for (int i = 0; i < visitedList.size(); i++) {
                System.out.println((i + 1) + ") " + visitedList.get(i));
            }
        } else {
            System.out.println("You should buy new ticket");
        }
    }


    public void pay() throws SQLException {
        int newMoney;
        System.out.println("How many money you want pay?");
        System.out.print("Cost: ");
        newMoney = Main.scanner.nextInt();
        updateDB.updateWallet(id, newMoney);
    }

    public void joinProgram() {
        if (calendar != null && calendar.getTime().after(calendar1.getTime())) {
            System.out.println("What program do you want to visit?");
            //Main.site.showPublicProgram();
            choice = Main.scanner.nextInt();
            if (!visitedList.contains(Main.site.publicProgramList.get(choice - 1).name)) {
                Main.site.publicProgramList.get(choice - 1).programList.add(this);
                visitedList.add(Main.site.publicProgramList.get(choice - 1).name);
                System.out.println(Main.site.publicProgramList.get(choice - 1).programList);
            } else {
                System.out.println("You are already on it");
            }
        } else {
            System.out.println("You should buy new ticket");
        }
    }

    public void buyTicket() throws SQLException {
        //Main.site.showTicketList();
        System.out.print("What package do you want? Enter the cost: ");
        choice = Main.scanner.nextInt();
        if (Main.site.prices.containsKey(choice)) {
            updateDB.updateWallet(id, -choice);
            updateDB.updateDate(id, choice);
        } else {
            System.out.println("Wrong enter");
        }
    }


    public void deleteProgram() {
        if (calendar != null && calendar.getTime().after(calendar1.getTime())) {
            if (!visitedList.isEmpty()) {
                for (int i = 0; i < visitedList.size(); i++) {
                    System.out.println((i + 1) + ") " + visitedList.get(i));
                }

                choice = Main.scanner.nextInt();
                for (PublicProgram elem : Main.site.publicProgramList) {
                    if (elem.name == visitedList.get(choice - 1)) {
                        elem.programList.remove(this);
                    }
                }
                visitedList.remove(choice - 1);
            } else {
                System.out.println("You haven't current programs");
            }
        } else {
            System.out.println("You should buy new ticket");
        }
    }

    @Override
    public String toString() {
        return "VisitorPackage.Member{" +
                "name='" + name + '\'' +
                ", gender=" + gender +
                ", age=" + age +
                '}';
    }
}