package VisitorPackage;

import MainPackage.Main;

import java.sql.SQLException;

public class Admin extends Visitor{

    public Admin(){
        anketaDB();
    }

    public Admin(String id, String name, String secondName, int age) {
        super(id, name, secondName, age);
    }

    public void anketaDB() {
        System.out.print("Enter name: ");
        name = Main.scanner.nextLine();
        name = Main.scanner.nextLine();
        System.out.print("Enter second name: ");
        secondName = Main.scanner.nextLine();
        System.out.print("Enter age: ");
        age = Main.scanner.nextInt();
        System.out.print("Enter password: ");
        id = Main.scanner.nextLine();
        id = Main.scanner.nextLine();
    }

    @Override
    public void visitorShowMenu() {
        do {
            System.out.println();
            System.out.println("1) Open current members");
            System.out.println("2) Open current trainers");
            System.out.println("3) Open current programs");
            System.out.println("4) Open trainers id");
            System.out.println("0) Return to Admin menu");
            visitorShowLogistic();
        } while (choice != 0);
    }

    @Override
    public void visitorAddMenu() throws SQLException {
        do {
            System.out.println();
            System.out.println("1) Add new trainer");
            System.out.println("0) Return to VisitorPackage.Admin menu");
            visitorAddLogistic();
        } while (choice != 0);
    }

    @Override
    public void visitorDelMenu() throws SQLException {
        do {
            System.out.println();
            System.out.println("1) Remove trainer");
            System.out.println("0) Return to VisitorPackage.Admin menu");
            visitorDelLogistic();
        } while (choice != 0);
    }

    @Override
    public void visitorShowLogistic() {
        if (checkChoice()) {
            switch (choice) {
                case 1:
                    showDB.showMembers();
                    break;
                case 2:
                    showDB.showEmployeeByStatus(0, false);
                    break;
                case 3:
                    showDB.showPrograms();
                    break;
                case 4:
                    showDB.showEmployeeByStatus(0, true);
                    break;
                case 0:
                    return;
            }
        }
        System.out.println();
    }

    @Override
    public void visitorAddLogistic() throws SQLException {
        if (checkChoice()) {
            switch (choice) {
                case 1:
                    addTrainer();
                    break;
                case 0:
                    return;
            }
        }
        System.out.println();
    }

    @Override
    public void visitorDelLogistic() throws SQLException {
        if (checkChoice()) {
            System.out.print("Enter your answer - ");
            choice = Main.scanner.nextInt();
            System.out.println();
            switch (choice) {
                case 1:
                    delTrainer();
                    break;
                case 0:
                    return;
            }
        }
        System.out.println();
    }

    @Override
    public String toString() {
        return "VisitorPackage.Admin{" +
                "name='" + name + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}