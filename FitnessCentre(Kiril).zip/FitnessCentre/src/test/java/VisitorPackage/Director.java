package VisitorPackage;

import MainPackage.Main;

import java.sql.SQLException;


public class Director extends Visitor{

    public Director(){}

    public Director(String id, String name, String secondName, int age) {
        super(id, name, secondName, age);
    }

    @Override
    public void visitorShowMenu() {
        do {
            System.out.println();
            System.out.println("1) Open current members");
            System.out.println("2) Open current trainers");
            System.out.println("3) Open current admins");
            System.out.println("4) Open current programs");
            System.out.println("5) Open admins id");
            System.out.println("6) Open trainers id");
            System.out.println("0) Return to VisitorPackage.Director menu");
            visitorShowLogistic();
        } while (choice != 0);
    }

    @Override
    public void visitorAddMenu() throws SQLException {
        do {
            System.out.println();
            System.out.println("1) Add new admin");
            System.out.println("2) Add new trainer");
            System.out.println("0) Return to VisitorPackage.Director menu");
            visitorAddLogistic();
        } while (choice != 0);
    }

    @Override
    public void visitorDelMenu() throws SQLException {
        do {
            System.out.println();
            System.out.println("1) Remove trainer");
            System.out.println("2) Remove admin");
            System.out.println("0) Return to Director menu");
            visitorDelLogistic();
        } while (choice != 0);
    }

    @Override
    public void visitorShowLogistic() {
        if (checkChoice()) {
            switch (choice) {
                case 1:
                    showDB.showMembers();
                    break;
                case 2:
                    showDB.showEmployeeByStatus(0,false);
                    break;
                case 3:
                    showDB.showEmployeeByStatus(1,false);
                    break;
                case 4:
                    showDB.showPrograms();
                    break;
                case 5:
                    showDB.showEmployeeByStatus(1,true);
                    break;
                case 6:
                    showDB.showEmployeeByStatus(0,true);
                    break;
                case 0:
                    return;
            }
        }
        System.out.println();
    }

    @Override
    public void visitorAddLogistic() throws SQLException {
        if (checkChoice()) {
            switch (choice) {
                case 1:
                    addAdmin();
                    break;
                case 2:
                    addTrainer();
                    break;
                case 0:
                    return;
            }
        }
        System.out.println();
    }

    @Override
    public void visitorDelLogistic() throws SQLException {
        if (checkChoice()) {
            switch (choice) {
                case 1:
                    delTrainer();
                    break;
                case 2:
                    delAdmin();
                    break;

                case 0:
                    return;
            }
            visitorDelMenu();
        }
        System.out.println();
    }


    private void addAdmin() throws SQLException {
      insertDB.newEmployee( 1);
    }

    private void delAdmin() throws SQLException {
        System.out.print("Enter admin id for remove: ");
        String enter = Main.scanner.nextLine();
        enter = Main.scanner.nextLine();
        deleteDB.deletePeople(enter, "employee");
    }
}
