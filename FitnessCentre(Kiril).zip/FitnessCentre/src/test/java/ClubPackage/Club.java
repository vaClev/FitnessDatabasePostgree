package ClubPackage;

import DataBase.*;
import MainPackage.*;

import java.util.*;

public class Club extends DataBase {

    static InsertDB insertDB = new InsertDB();
    static ReturnDB returnDB = new ReturnDB();
    static ShowDB showDB = new ShowDB();
    public List<PublicProgram> publicProgramList = new ArrayList<>();
    public Map<Integer, Integer> prices = new HashMap<>();

    public void createPrices() {
        prices.put(2500, Calendar.MONTH);
        prices.put(25000, Calendar.YEAR);
    }
}
