package ClubPackage;

import MainPackage.Main;
import VisitorPackage.Member;
import VisitorPackage.Visitor;


import java.sql.SQLException;
import java.util.InputMismatchException;



public class Site extends Club {



    public void greeting() throws SQLException {

        System.out.println("We glad to see you on out site!");
        System.out.println("\'Description\'");
        while (true) {
            menu();
        }
    }

    public void menu() throws SQLException {
        while (true) {

            System.out.println("" +
                    "Menu:\n" +
                    "1) Become a new member\n" +
                    "2) Look at public programs\n" +
                    "3) Look at price\n" +
                    "4) Sign in like a Member\n" +
                    "5) Sign in like a Trainer\n" +
                    "6) Sign in like a Administrator\n" +
                    "7) Sign in like a Director\n" +
                    "0) Exit from site");
            logistic();

        }
    }

    public void logistic() throws SQLException {
        int answer;
        try {
            System.out.print("Enter your answer - ");
            answer = Main.scanner.nextInt();
        } catch (InputMismatchException ex) {
            System.out.println("Error");
            Main.scanner.nextLine();
            return;
        }
            switch (answer) {
                case 1:
                    insertDB.newMember();
                    break;
                case 2:
                    showDB.showPrograms();
                    break;
                case 3:
//                    showTicketList();
                    break;
                case 4:
                    joinMember();
                    break;
                case 5:
                case 6:
                case 7:
                    joinEmployee();
                    break;
                case 0:
                    System.exit(0);

                default:
                    System.out.println("Wrong enter");
            }
            System.out.println();
    }

    private void joinEmployee() throws SQLException {
        System.out.print("Please enter the password: ");
        String employeePassword = Main.scanner.nextLine();
        employeePassword = Main.scanner.nextLine();
        Visitor visitor = returnDB.findVisitorByPassword(employeePassword);
        visitor.visitorMenu();
    }

    private void joinMember() throws SQLException {
        System.out.print("Please enter the password: ");
        String memberPassword = Main.scanner.nextLine();
        memberPassword = Main.scanner.nextLine();
        Member temp = returnDB.findMemberByPassword(memberPassword);
        temp.visitorMenu();
    }
}
