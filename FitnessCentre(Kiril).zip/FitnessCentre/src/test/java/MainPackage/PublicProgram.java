package MainPackage;

import DataBase.DataBase;
import VisitorPackage.Member;
import VisitorPackage.Trainer;

import java.util.LinkedList;
import java.util.List;

public class PublicProgram extends DataBase {
    static int numOfPrograms = 0;
    public String name;
    Trainer trainer;
    public int duration;
    public int maxMembers;
    public List<Member> programList = new LinkedList<>();

    public PublicProgram(String name, Trainer trainer) {
        this.trainer = trainer;
        this.name = name;
        System.out.print("Enter duration - ");
        duration = Main.scanner.nextInt();
        System.out.print("Enter max member - ");
        maxMembers = Main.scanner.nextInt();
    }

    PublicProgram(String name, Trainer trainer, int duration, int maxMembers) {
        this.name = name;
        this.trainer = trainer;
        this.duration = duration;
        this.maxMembers = maxMembers;
//        MainPackage.Main.site.trainerList.get(numOfPrograms).trainerProgramList.add(this.name);
        numOfPrograms++;
    }

    @Override
    public String toString() {
        return "MainPackage.PublicProgram{" +
                "name='" + name + '\'' +
                ", trainer=" + trainer +
                '}';
    }
}
