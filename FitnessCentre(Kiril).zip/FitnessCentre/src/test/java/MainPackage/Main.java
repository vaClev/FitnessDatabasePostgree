package MainPackage;

import ClubPackage.Site;

import java.sql.SQLException;
import java.util.*;

public class Main {
    public static Scanner scanner = new Scanner(System.in);
    public static Site site = new Site();

    public static void main(String[] args) throws SQLException {
        site.createPrices();
        site.greeting();
    }
}
